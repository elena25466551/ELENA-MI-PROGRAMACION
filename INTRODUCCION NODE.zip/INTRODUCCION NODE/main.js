//console.log(module)
//console.log(require)
//console.log(__dirname)
console.log(__filename)